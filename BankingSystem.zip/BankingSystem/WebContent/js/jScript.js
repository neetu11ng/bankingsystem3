/**
 * 
 */
function hide()
{
	document.getElementById("hidenew").style.display="none";
}
function show()
{
	document.getElementById("generate").style.display="block";
}
function on() 
{
	  document.getElementById("request").style.display = "block";
}