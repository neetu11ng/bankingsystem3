package com.caps.banking.Controller;

import java.io.IOException;
import java.sql.ResultSet;
import java.util.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.caps.banking.dto.RequestBean;
import com.caps.banking.dto.UserBean;
import com.caps.banking.service.RequestService;
import com.caps.banking.service.UserService;

/**
 * Servlet implementation class RequestCheckServlet
 */
@WebServlet("/RequestCheck")
public class RequestCheckServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RequestCheckServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		System.out.println("Enter in request servlet");
		
		HttpSession hs=request.getSession(false);
		String ui=(String)hs.getAttribute("userInfo");
		
		System.out.println(ui);
		
		String requestNo = request.getParameter("srn");
		long reques = Long.parseLong(requestNo);
		int ac = 0;
		
		UserBean ub = new UserBean();
		ub.setUser_id(ui);
		
		UserService us = new UserService();
		ResultSet u = us.fetchData(ub);
		try
		{
			if (u.next()) 
			{
				ac = u.getInt("ac_id");
			}
		}
		catch (Exception e) 
		{
			// TODO: handle exception
		}
		
		RequestBean rb = new RequestBean();
		rb.setServiceId(reques);
		rb.setAcId(ac);
		rb.setServiceDesc("Request for Check Book");
		rb.setRequestDate(new Date());
		rb.setStatus("Requested");
		
		RequestService rs = new RequestService();
		boolean chk = rs.chkbookReq(rb);
		System.out.println(chk);
		if(chk)
		{
			System.out.println("Successfully requested");
			
			request.setAttribute("alert", "Save SRN number for future use.");
    		RequestDispatcher rd=request.getRequestDispatcher("/HTML/UserHome.jsp");
    		rd.forward(request,response);
    		
		}
		else {
			System.out.println("Unsuccessful");
			
			request.setAttribute("alert", "Save SRN number for future use.");
    		RequestDispatcher rd=request.getRequestDispatcher("/HTML/UserHome.jsp");
    		rd.forward(request,response);
		}
		
		
	}

}
