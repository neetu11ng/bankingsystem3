package com.caps.banking.Controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.caps.banking.dto.PayeeBean;
import com.caps.banking.service.PayeeService;

@WebServlet("/payee")
public class PayeeServlet extends HttpServlet
{
	/**
	 * 
	 */
	private static final long serialVersionUID = -8599826122049099810L;

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException
	{
		//PrintWriter out = resp.getWriter();
		resp.setContentType("text/html");
		
		String a_id = req.getParameter("acId");
		String acNo = req.getParameter("acNo");
		String nickName = req.getParameter("nickname");
		
		int id = Integer.parseInt(a_id);
		int no = Integer.parseInt(acNo);
		
		PayeeBean pb = new PayeeBean();
		pb.setAc_id(id);
		pb.setPayee_ac_num(no);
		pb.setNick_name(nickName);
		
		PayeeService ps = new PayeeService();
		boolean check = ps.checkId(no);
		if(check)
		{
			boolean add = ps.addContact(pb);
			if(add)
			{
				//resp.sendRedirect("/BankingSystem/HTML/AddPayee.jsp");
				
				req.setAttribute("msg", "Payee added to contact");
				RequestDispatcher rd = req.getRequestDispatcher("/HTML/AddPayee.jsp");
				rd.forward(req, resp);
			}
			else
			{
				req.setAttribute("msg", "Account Id is not registered in Bank");
				RequestDispatcher rd = req.getRequestDispatcher("/HTML/AddPayee.jsp");
				rd.forward(req, resp);
			}
		}
		else 
		{
			req.setAttribute("msg", "Account Id is not registered in Bank");
			RequestDispatcher rd = req.getRequestDispatcher("/HTML/AddPayee.jsp");
			rd.forward(req, resp);
		}
		
	}
}
