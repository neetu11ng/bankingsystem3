package com.caps.banking.Controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.caps.banking.dto.UserBean;
import com.caps.banking.service.UserService;


@WebServlet("/addDetails")
public class UserAddDetailsServlet extends HttpServlet 
{
	/**
	 * 
	 */
	private static final long serialVersionUID = -5456810532375479125L;

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException 
	{
		
		PrintWriter out = resp.getWriter();
		resp.setContentType("text/html");

		String a_id = req.getParameter("ac_id");
		String u_id = req.getParameter("user_id");
		String pass = req.getParameter("pass");
		String re_pass = req.getParameter("re_pass");
		String ques = req.getParameter("question");
		String answer = req.getParameter("answer");
		String t_pass = req.getParameter("t_pass");
		String re_t_pass = req.getParameter("re_t_pass");

		System.out.println("Data recevied");

		if (pass.equals(re_pass) || t_pass.equals(re_t_pass)) {
			int id = Integer.parseInt(a_id);
			// int uid =Integer.parseInt(u_id);

			UserBean ub = new UserBean();
			ub.setAc_id(id);
			ub.setUser_id(u_id);
			ub.setLogin_password(pass);
			ub.setSecret_question(ques);
			ub.setAnswer(answer);
			ub.setTransaction_password(t_pass);

			UserService us = new UserService();
			boolean b = us.userRegister(ub);

			if (b) {
				resp.sendRedirect("/BankingSystem/loginpage.html");
			} else {
				out.print("Data not completed");
			}

		} else {
			out.println("Password not matched !!");
		}
	}
}
