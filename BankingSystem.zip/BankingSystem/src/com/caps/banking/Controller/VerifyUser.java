package com.caps.banking.Controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.caps.banking.service.BankExtraService;

@WebServlet("/verify")
public class VerifyUser extends HttpServlet
{

	/**
	 * 
	 */
	private static final long serialVersionUID = 8823284557994716398L;
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException 
	{
		String id = req.getParameter("uid");
		System.out.println("verify of "+id);
		BankExtraService bs = new BankExtraService();
		bs.verify(id);
		
		req.setAttribute("alert", "User verified !!");
		RequestDispatcher rd=req.getRequestDispatcher("/HTML/ViewDetailsUser.jsp");
		rd.forward(req,resp);
	}
}
