package com.caps.banking.Controller;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.caps.banking.dto.UserBean;
import com.caps.banking.service.UserService;

@WebServlet("/applyNew")
public class RegisterServlet extends HttpServlet
{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 4906517297395902685L;

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException 
	{
		PrintWriter out = resp.getWriter();
		resp.setContentType("text/html");
		
		
		String u_id = req.getParameter("user_id");
		String name = req.getParameter("uname");
		String email = req.getParameter("email");
		String address = req.getParameter("address");
		String pan = req.getParameter("pan");
		String ac_no = req.getParameter("ac_no");
		String contact = req.getParameter("contact");
		
		System.out.println("Data recevied");
	
		if(ac_no.equals(null) ||  ac_no.equals(""))
		{
			ac_no="0";
		}
				int ac =Integer.parseInt(ac_no);
				int phone  =Integer.parseInt(contact);
				
				UserBean ub = new UserBean();
				ub.setUser_id(u_id);
				ub.setUname(name);
				ub.setEmail(email);
				ub.setAddress(address);
				ub.setPan(pan);
				ub.setAc_no(ac);
				ub.setContact(phone);
				
				UserService us = new UserService();
				boolean b= us.userRegister(ub);

			    if(b)
			    {
			    	resp.sendRedirect("/BankingSystem/HTML/Login.jsp");
			    }
			    else
			    {
			    	out.print("Data not completed");
			    }				

	}
}
