package com.caps.banking.Controller;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import com.caps.banking.dto.UserBean;
import com.caps.banking.service.UserService;

@WebServlet("/login")
public class LoginServlet extends HttpServlet
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 8458061683659392281L;

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException 
	{
		//PrintWriter out = resp.getWriter();
		resp.setContentType("text/html");
		
		String u_id = req.getParameter("name");
		String pass = req.getParameter("password");
		
		//setting data
		UserBean ub = new UserBean();
		ub.setUser_id(u_id);
		ub.setLogin_password(pass);
		
		//service or implementation
		UserService us = new UserService();
		boolean b = us.userLogin(ub);
		
	    if(b)
	    {
			ResultSet rs = us.fetchData(ub);
			try {
				if (rs.next()) 
				{
					ub.setAc_id(rs.getInt("ac_id"));

					// session creation
					HttpSession session = req.getSession();
					session.setAttribute("userInfo", ub.getUser_id());
					session.setAttribute("ac", ub.getAc_id());
					
					// checking it is admin or user

					if (u_id.equals("Admin") && pass.equals("ADMIN")) 
					{
						resp.sendRedirect("/BankingSystem/HTML/AdminHome.jsp");
						System.out.println("Adminhome");

					} else 
					{
						resp.sendRedirect("/BankingSystem/HTML/UserHome.jsp");
						System.out.println("UserHome");
					}
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
	    else 
	    {
	    		req.setAttribute("msg", "invalid userid or password");
	    		RequestDispatcher rd=req.getRequestDispatcher("/HTML/Login.jsp");
	    		rd.forward(req,resp);
		}
	}
}
