package com.caps.banking.Controller;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.caps.banking.dto.UserBean;
import com.caps.banking.service.UserService;

/**
 * Servlet implementation class UpdateMobileServlet
 */
@WebServlet("/UpdateMobile")
public class UpdateMobileServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UpdateMobileServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		System.out.println("Enter in servelet");
		
		HttpSession hs=request.getSession(false);
		String ui=(String)hs.getAttribute("userInfo");
		
		System.out.println(ui);
		
		String old = request.getParameter("currentMob");
		String newMob = request.getParameter("newMob");
		
		Integer oldphone = Integer.parseInt(newMob);
		int newphone = Integer.parseInt(newMob);
		
		UserBean ub = new UserBean();
		ub.setUser_id(ui);
		
		UserService us = new UserService();
		ResultSet rs = us.fetchDataCustomer(ub);
		try 
		{
			if (rs.next()) 
			{
				int mob = rs.getInt("contact_number");
				if(oldphone.equals(mob))
				{
					ub.setContact(newphone);
					boolean b = us.updateMobile(ub);
					if(b)
					{
						request.setAttribute("msg", "Mobile number Updated");
			    		RequestDispatcher rd=request.getRequestDispatcher("/HTML/UserHome.jsp");
			    		rd.forward(request,response);
					}
					else 
					{
						request.setAttribute("msg", "Something went wrong");
			    		RequestDispatcher rd=request.getRequestDispatcher("/HTML/UserHome.jsp");
			    		rd.forward(request,response);
					}
				}
				else
				{
					request.setAttribute("msg", "Current Mobile number not correct ");
		    		RequestDispatcher rd=request.getRequestDispatcher("/HTML/UpdatePassword.jsp");
		    		rd.forward(request,response);
				}
			}
		} catch (SQLException e) 
		{
			e.printStackTrace();
		}
	}

}
