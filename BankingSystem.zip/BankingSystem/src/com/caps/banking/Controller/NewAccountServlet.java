package com.caps.banking.Controller;

import java.io.IOException;
import java.util.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.caps.banking.dto.NewAccountBean;
import com.caps.banking.dto.UserBean;
import com.caps.banking.service.BankExtraService;

@WebServlet("/newAccount")
public class NewAccountServlet extends HttpServlet
{

	/**
	 * 
	 */
	private static final long serialVersionUID = 2048848997607948764L;
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException 
	{
		String uid = req.getParameter("uid");
		String acno = req.getParameter("acno");
		String type = req.getParameter("acType");
		String balance = req.getParameter("balance");
		
		long ac_no = Integer.parseInt(acno);
		double bal = Double.parseDouble(balance);
		
		NewAccountBean nb = new NewAccountBean();
		nb.setAcId(ac_no);
		nb.setAcType(type);
		nb.setBal(bal);
		nb.setOpenDate(new Date());
		
		UserBean ub = new UserBean();
		ub.setAc_id(ac_no);
		ub.setUser_id(uid);
		ub.setLogin_password("0000");
		
		BankExtraService bs = new BankExtraService();
		boolean b = bs.newAccount(nb);
		
		if(b)
		{
			bs.insUser(ub);
			req.setAttribute("error", "Account Created !!");
    		RequestDispatcher rd=req.getRequestDispatcher("/HTML/ViewDetailsUser.jsp");
    		rd.forward(req,resp);
		}
		else 
		{
			req.setAttribute("error", "Data not completed !!");
    		RequestDispatcher rd=req.getRequestDispatcher("/HTML/ViewDetailsUser.jsp");
    		rd.forward(req,resp);
		}
	}

}
