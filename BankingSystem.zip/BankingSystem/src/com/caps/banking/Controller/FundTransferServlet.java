package com.caps.banking.Controller;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.caps.banking.dto.FundBean;
import com.caps.banking.dto.NewAccountBean;
import com.caps.banking.dto.TransactionBean;
import com.caps.banking.service.BankExtraService;
import com.caps.banking.service.FundService;
import com.caps.banking.service.PayeeService;
import com.caps.banking.service.TransactionService;

@WebServlet("/fundtransfer")
public class FundTransferServlet extends HttpServlet
{

	/**
	 * 
	 */
	private static final long serialVersionUID = -8421006583641054765L;
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException 
	{
		
		HttpSession hs = req.getSession(false);
		String ui = (String)hs.getAttribute("userInfo");
		
		Long ac = (Long)hs.getAttribute("ac");
		System.out.println(ac);
		
		
		String acid = req.getParameter("acno");
		String amount = req.getParameter("money");
		String desc = req.getParameter("desc");
		double fund = Double.parseDouble(amount);
		System.out.println(fund);
		
		NewAccountBean nb = new NewAccountBean();//fetching account details
		nb.setAcId(ac);
		long payeeNo= 0;
		PayeeService ps = new PayeeService();
		ResultSet rs1 = ps.allDetailByName(acid);

		try
		{
			if(rs1.next())
			{
				payeeNo = rs1.getLong("payee_ac_number");
				
			}
		}
		catch (Exception e) 
		{
			// TODO: handle exception
		}
		
		FundBean fb = new FundBean();
		fb.setAcId(ac);
		fb.setPayeeAcId(payeeNo);
		fb.setTransferAmount(fund);
		
		try
		{
			long a = nb.getAcId();
			BankExtraService bs = new BankExtraService(); //checking account balance
			ResultSet rs = bs.accountDetails(a);
			boolean bool = rs.next();
			System.out.println("bool "+bool);
			if(bool) 
			{
				double bal = rs.getDouble("balance");
				System.out.println("available bal "+bal);
				
				//checking account balance
				if(bal>fund)
				{
//					TransactionBean tb = new TransactionBean();
//					tb.setAc_id(ac);
//					tb.setTran_desc("Debit");
//					tb.setTran_amount(fund);
//					tb.setTran_desc(desc);
					
					FundService fs = new FundService();
					TransactionService ts = new TransactionService();
					boolean b = fs.funding(fb);
					if(b)
					{
						fs.updateBal(fb, bal);
//						ts.createTrans(tb);
						req.setAttribute("msg", "Fund Transfer successful ");
			    		RequestDispatcher rd=req.getRequestDispatcher("/HTML/FundTransfer.jsp");
			    		rd.forward(req,resp);
					}
					else 
					{
						req.setAttribute("msg", "Something went wrong ");
			    		RequestDispatcher rd=req.getRequestDispatcher("/HTML/FundTransfer.jsp");
			    		rd.forward(req,resp);
					}
				}
				else 
				{
					req.setAttribute("msg", "Balance is not sufficient to send ");
		    		RequestDispatcher rd=req.getRequestDispatcher("/HTML/FundTransfer.jsp");
		    		rd.forward(req,resp);
				}
			}
			else 
			{
				req.setAttribute("msg", "Data not found ");
	    		RequestDispatcher rd=req.getRequestDispatcher("/HTML/FundTransfer.jsp");
	    		rd.forward(req,resp);
			}
		}
		catch (Exception e) 
		{
			// TODO: handle exception
		}	
	}

}
