package com.caps.banking.dao;

import com.caps.banking.dto.TransactionBean;

public interface TransI 
{
	void insertTransaction(TransactionBean tb);
	boolean viewTransaction(int transaction_id);
}
