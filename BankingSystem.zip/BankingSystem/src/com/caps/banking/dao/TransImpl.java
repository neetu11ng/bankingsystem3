package com.caps.banking.dao;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.caps.banking.dto.TransactionBean;
import com.caps.banking.utils.DBUtils;

public class TransImpl implements TransI, DBUtils 
{
	Connection con =null;
	PreparedStatement ps =null;
	ResultSet rs = null;
	String query;
	
	
	@Override
	public boolean viewTransaction(int transaction_id) {
		try 
		{
			Class.forName(DRIVERCLASS).newInstance();
			con = DriverManager.getConnection(DBURL, USER, PASSWORD);

			query="select * from transactions where transation_id=?";
			ps = con.prepareStatement(query);
			ps.setInt(1,transaction_id);
			ResultSet rs = ps.executeQuery();

			while(rs.next())
			{
				System.out.println("submitted");
				return true;
			}
		}catch(Exception e) {
			e.printStackTrace();
			System.out.println(e);
		}
		return false;
	}


	@Override
	public void insertTransaction(TransactionBean tb) 
	{
		java.util.Date d =  tb.getDate_of_tran();
		Date date = new Date(d.getTime());
		try 
		{
			con = DriverManager.getConnection(DBURL, USER, PASSWORD);
			
			query ="insert into transactions (trans_desc,date_of_tran,transaction_type,tran_amount,ac_id) value (?,?,?,?,?)";
			ps = con.prepareStatement(query);

			ps.setString(1, tb.getTran_desc());
			ps.setDate(2, date);
			ps.setString(3, tb.getTransaction_type());
			ps.setDouble(4, tb.getTran_amount());
			ps.setLong(5, tb.getAc_id());
			
			int count = ps.executeUpdate();
			
			if(count>0)
			{
				System.out.println("transaction created....");
			}
			else
			{
				System.out.println("Invalid data or incomplete data ");
			}
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
			System.out.println(e);
		}
		
	}
}


