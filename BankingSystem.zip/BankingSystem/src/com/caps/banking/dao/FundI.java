package com.caps.banking.dao;

import com.caps.banking.dto.FundBean;

public interface FundI 
{
	boolean fundTransfer(FundBean fb); 
	void updateBalance(FundBean fb, double bal);
}
