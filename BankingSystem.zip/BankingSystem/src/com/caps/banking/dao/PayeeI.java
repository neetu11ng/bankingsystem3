package com.caps.banking.dao;

import java.sql.ResultSet;

import com.caps.banking.dto.PayeeBean;

public interface PayeeI 
{
	boolean addPayee(PayeeBean pb);
	boolean checkAccountId(int accountId);
	ResultSet fetchPayeeDetails(long accountId);
	ResultSet PayeeDetails(String name);
}
