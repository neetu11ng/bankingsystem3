package com.caps.banking.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.caps.banking.dto.UserBean;
import com.caps.banking.utils.DBUtils;

public class UserImpl implements UserI , DBUtils
{
	Connection con =null;
	PreparedStatement ps =null;
	ResultSet rs = null;
	String query;
	

	@Override
	public boolean register(UserBean ub) 
	{
		try 
		{
			Class.forName(DRIVERCLASS).newInstance();
			//DriverManager.registerDriver(driver);
			con = DriverManager.getConnection(DBURL, USER, PASSWORD);
			
			query="insert into customer values (?,?,?,?,?,?,?,?)";
			ps = con.prepareStatement(query);
			ps.setString(1, ub.getUser_id());
			ps.setString(2, ub.getUname());
			ps.setString(3, ub.getEmail());
			ps.setString(4, ub.getAddress());
			ps.setString(5, ub.getPan());
			ps.setInt(6, ub.getAc_no());
			ps.setString(7, "F");
			ps.setInt(8, ub.getContact());
			
			int count = ps.executeUpdate();
			
			if(count>0)
			{
				System.out.println("Data inserted....");
				return true;
				
			}
			else
			{
				System.out.println("Invalid data or incomplete data ");
				return false;
			}
			
			
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
			System.out.println(e);
		}
		return false;
	}

	@Override
	public boolean login(UserBean ub) 
	{
		try 
		{
			Class.forName(DRIVERCLASS).newInstance();
			con = DriverManager.getConnection(DBURL, USER, PASSWORD);
			
			query="select * from user_table where user_id=? and login_password=?";
			ps = con.prepareStatement(query);
			ps.setString(1, ub.getUser_id());
			ps.setString(2, ub.getLogin_password());
			ResultSet rs = ps.executeQuery();
			
			if(rs.next())
			{
				return true;
			}
			else
			{
				return false;
			}
			
			
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		}	
		return false;
	}

	@Override
	public boolean details(UserBean ub) 
	{
		try 
		{
			Class.forName(DRIVERCLASS).newInstance();
			//DriverManager.registerDriver(driver);
			con = DriverManager.getConnection(DBURL, USER, PASSWORD);
			
			query="insert into user_table value (?,?,?,?,?,?,?)";
			ps = con.prepareStatement(query);
			ps.setLong(1, ub.getAc_id());
			ps.setString(2, ub.getUser_id());
			ps.setString(3, ub.getLogin_password());
			ps.setString(4, ub.getSecret_question());
			ps.setString(5, ub.getAnswer());
			ps.setString(6, ub.getTransaction_password());
			ps.setString(7, "F");
			int count = ps.executeUpdate();
			
			if(count>0)
			{
				System.out.println("Data inserted....");
				return true;
			}
			else
			{
				System.out.println("Invalid data or incomplete data ");
				return false;
			}
			
			
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
			System.out.println(e);
		}
		return false;
		
	}

	@Override
	public boolean updatePass(UserBean ub) 
	{
		try
		{
			Class.forName(DRIVERCLASS).newInstance();
			//DriverManager.registerDriver(driver);
			con = DriverManager.getConnection(DBURL, USER, PASSWORD);
			
			query="update user_table set login_password=? where user_id=?";
			ps = con.prepareStatement(query);
			ps.setString(1, ub.getLogin_password());
			ps.setString(2, ub.getUser_id());
			
			int count = ps.executeUpdate();
			
			if(count>0)
			{
				System.out.println("Data inserted....");
				return true;
			}
			else
			{
				System.out.println("Invalid data or incomplete data ");
				return false;
			}
			
			
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		}
		return false;
	}

	@Override
	public ResultSet fetchData(UserBean ub) 
	{
		ResultSet rs= null;
		try 
		{
			Class.forName(DRIVERCLASS).newInstance();
			con = DriverManager.getConnection(DBURL, USER, PASSWORD);
			
			query="select * from user_table where user_id=? ";
			ps = con.prepareStatement(query);
			ps.setString(1, ub.getUser_id());
			rs = ps.executeQuery();
			
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		}	
		return rs;
	}

	@Override
	public boolean updateMob(UserBean ub) 
	{
		try
		{
			Class.forName(DRIVERCLASS).newInstance();
			
			con = DriverManager.getConnection(DBURL, USER, PASSWORD);
			
			query="update customer set contact_number = ? where user_id=?";
			ps = con.prepareStatement(query);
			ps.setInt(1, ub.getContact());
			ps.setString(2, ub.getUser_id());
			
			int count = ps.executeUpdate();
			
			if(count>0)
			{
				System.out.println("Mobile no. updated");
				return true;
			}
			else
			{
				System.out.println("Invalid number or incomplete  ");
				return false;
			}
			
			
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		}
		return false;
	}

	@Override
	public ResultSet fetchDataCustomer(UserBean ub) 
	{
		ResultSet rs= null;
		try 
		{
			Class.forName(DRIVERCLASS).newInstance();
			con = DriverManager.getConnection(DBURL, USER, PASSWORD);
			
			query="select * from customer where user_id=? ";
			ps = con.prepareStatement(query);
			ps.setString(1, ub.getUser_id());
			rs = ps.executeQuery();
			
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		}	
		return rs;
	}

}
