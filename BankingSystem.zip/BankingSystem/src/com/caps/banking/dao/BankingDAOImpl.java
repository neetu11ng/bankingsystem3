package com.caps.banking.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Date;
import java.util.Scanner;

import com.caps.banking.dto.NewAccountBean;
import com.caps.banking.dto.UserBean;
import com.caps.banking.utils.DBUtils;

public class BankingDAOImpl implements BankingDAO ,DBUtils
{
	Scanner sc = new Scanner(System.in);
	
	Connection con =null;
	PreparedStatement ps =null,ps1=null;
	ResultSet rs = null;
	String query;
	

	@Override
	public void verifyUser(String id) 
	{
		
		try 
		{
			Class.forName(DRIVERCLASS).newInstance();
			con = DriverManager.getConnection(DBURL, USER, PASSWORD);			
			query="update customer set lock_status='T' where user_id=?";
			ps = con.prepareStatement(query);
			ps.setString(1, id);
			int count = ps.executeUpdate();
			
			if(count>0)
			{
				System.out.println("Data updated....");
			}
			else
			{
				System.out.println("Invalid data or incomplete data ");
			}
		}
		catch (Exception e) 
		{
			e.printStackTrace();
		}
			
			
	}
	
	public void insUser(UserBean ub)
	{
		try 
		{
			con = DriverManager.getConnection(DBURL, USER, PASSWORD);
			
			String query2 ="insert into user_table(ac_id,user_id,login_password) value (?,?,?)";
			ps1 = con.prepareStatement(query2);
			ps1.setLong(1, ub.getAc_id());
			ps1.setString(2, ub.getUser_id());
			ps1.setString(3, ub.getLogin_password());

			System.out.println(" Ac_ id ="+ub.getAc_id());
			System.out.println("User id "+ub.getUser_id());
			
			int count = ps1.executeUpdate();
			
			if(count>0)
			{
				System.out.println("Account created....");
			}
			else
			{
				System.out.println("Invalid data or incomplete data ");
			}
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
			System.out.println(e);
		}
	}

	@Override
	public boolean createNewAccount(NewAccountBean nb) 
	{
		
		java.util.Date d =  nb.getOpenDate();
		Date date = new Date(d.getTime());
		
		try 
		{
			con = DriverManager.getConnection(DBURL, USER, PASSWORD);
			
			query="insert into account_master value (?,?,?,?)";
			ps = con.prepareStatement(query);
			ps.setLong(1, nb.getAcId());
			ps.setString(2, nb.getAcType());
			ps.setDouble(3, nb.getBal());
			ps.setDate(4, date);
		
			int count = ps.executeUpdate();
			
			if(count>0)
			{
				System.out.println("Account created....");
				return true;
			}
			else
			{
				System.out.println("Invalid data or incomplete data ");
				return false;
			}
			
			
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
			System.out.println(e);
		}
		return false;
	}

	@Override
	public void viewTransaction() {
		// TODO Auto-generated method stub
		
	}


	@Override
	public void trackingService(int srno) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public ResultSet viewDetails(String id) {
		
		ResultSet rs= null;
		try 
		{
			Class.forName(DRIVERCLASS).newInstance();
			con = DriverManager.getConnection(DBURL, USER, PASSWORD);
			
			query="select * from customer where user_id=? ";
			ps = con.prepareStatement(query);
			ps.setString(1, id);
			rs = ps.executeQuery();
			
			return rs;
		} 
		catch (Exception e) {
			// TODO: handle exception
		}
		return rs;
	}


	@Override
	public ResultSet fetching() 
	{
		ResultSet rs = null;
		try 
		{
			Class.forName(DRIVERCLASS).newInstance();
			con = DriverManager.getConnection(DBURL, USER, PASSWORD);
			
			query="select * from customer where lock_status='F' ";
			ps = con.prepareStatement(query);
			rs = ps.executeQuery();
			
			return rs;
			
			
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		}	
		return rs;
	}

	@Override
	public ResultSet verifiedUser() 
	{
		try 
		{
			Class.forName(DRIVERCLASS).newInstance();
			con = DriverManager.getConnection(DBURL, USER, PASSWORD);
			
			query="select * from customer where lock_status='T' ";
			ps = con.prepareStatement(query);
			rs = ps.executeQuery();
			
			return rs;
			
			
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		}	
		return rs;
	}

	@Override
	public ResultSet accountDetails(long acid) throws SQLException
	{
		ResultSet rs = null;
		try 
		{
			Class.forName(DRIVERCLASS).newInstance();
			con = DriverManager.getConnection(DBURL, USER, PASSWORD);
			
			query="select * from account_master where ac_id=? ";
			ps = con.prepareStatement(query);
			ps.setLong(1, acid);
			rs = ps.executeQuery();
			
			
			
			return rs;
			
			
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		}	
		System.out.println("Fetching data");
		System.out.println(rs.next());
		System.out.println(rs.getDouble("balance"));
		return rs;
	}

}
