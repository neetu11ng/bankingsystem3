package com.caps.banking.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import com.caps.banking.dto.NewAccountBean;

public interface BankingDAO 
{
	void verifyUser(String id);
	boolean createNewAccount(NewAccountBean nb);
	void viewTransaction();
	void trackingService(int srno);
	ResultSet viewDetails(String id);
	ResultSet fetching();
	ResultSet verifiedUser();
	ResultSet accountDetails(long acid) throws SQLException;
}
