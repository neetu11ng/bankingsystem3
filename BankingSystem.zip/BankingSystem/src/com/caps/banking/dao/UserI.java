package com.caps.banking.dao;

import java.sql.ResultSet;

import com.caps.banking.dto.UserBean;

public interface UserI 
{
	boolean register(UserBean ub);
	boolean login(UserBean ub);
	boolean details(UserBean ub);
	boolean updatePass(UserBean ub);
	ResultSet fetchData(UserBean ub);
	boolean updateMob(UserBean ub);
	ResultSet fetchDataCustomer(UserBean ub);
}
