package com.caps.banking.dao;

import com.caps.banking.dto.RequestBean;

public interface RequestI 
{
	boolean checkRequest(RequestBean rb);
}
