package com.caps.banking.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.caps.banking.dto.PayeeBean;
import com.caps.banking.utils.DBUtils;

public class PayeeImpl implements PayeeI , DBUtils
{
	Connection con =null;
	PreparedStatement ps =null;
	ResultSet rs = null;
	String query;

	@Override
	public boolean addPayee(PayeeBean pb) 
	{
		try 
		{
			Class.forName(DRIVERCLASS).newInstance();
			con = DriverManager.getConnection(DBURL, USER, PASSWORD);
			
			query = "insert into payee_table value (?,?,?)";
			ps = con.prepareStatement(query);
			ps.setLong(1, pb.getAc_id());
			ps.setInt(2, pb.getPayee_ac_num());
			ps.setString(3, pb.getNick_name());
			
			int count = ps.executeUpdate();
			
			if(count>0)
			{
				System.out.println("Data inserted....");
				return true;
			}
			else
			{
				System.out.println("Invalid data or incomplete data ");
				return false;
			}
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
			System.out.println(e);
		}
		finally 
		{
			try
			{
				if (rs != null) 
					rs.close();
				if(ps!=null)
					ps.close();
				if(con!=null)
					con.close();
			}
			catch (Exception e) 
			{
				// TODO: handle exception
			}
		}
		return false;
	}

	@Override
	public boolean checkAccountId(int accountId) 
	{
		try 
		{
			Class.forName(DRIVERCLASS).newInstance();
			con = DriverManager.getConnection(DBURL, USER, PASSWORD);
			
			query = "select ac_id from account_master where ac_id=?";
			ps = con.prepareStatement(query);
			ps.setInt(1, accountId);
			
			rs  = ps.executeQuery();

			if(rs.next())
			{
				System.out.println("Account number is present ..");
				return true;
			}
			else
			{
				System.out.println("Invalid data  ");
				return false;
			}
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
			System.out.println(e);
		}
		finally 
		{
			try
			{
				if (rs != null) 
					rs.close();
				if(ps!=null)
					ps.close();
				if(con!=null)
					con.close();
			}
			catch (Exception e) 
			{
				// TODO: handle exception
			}
		}
		return false;
	}

	@Override
	public ResultSet fetchPayeeDetails(long accountId) 
	{
		try 
		{
			Class.forName(DRIVERCLASS).newInstance();
			con = DriverManager.getConnection(DBURL, USER, PASSWORD);
			
			query = "select * from payee_table where ac_id=?";
			ps = con.prepareStatement(query);
			ps.setLong(1, accountId);
			
			rs  = ps.executeQuery();

			return rs;
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
			System.out.println(e);
		}
		
		return rs;
	}

	@Override
	public ResultSet PayeeDetails(String name) 
	{
		ResultSet rs = null;
		try 
		{
			Class.forName(DRIVERCLASS).newInstance();
			con = DriverManager.getConnection(DBURL, USER, PASSWORD);
			
			query = "select * from payee_table where nick_name=?";
			ps = con.prepareStatement(query);
			ps.setString(1, name);
			
			rs  = ps.executeQuery();
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		}
		
		return rs;
	}

}
