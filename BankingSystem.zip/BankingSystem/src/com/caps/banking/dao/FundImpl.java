package com.caps.banking.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Date;

import com.caps.banking.dto.FundBean;
import com.caps.banking.utils.DBUtils;

public class FundImpl implements FundI, DBUtils
{
	Connection con =null;
	PreparedStatement ps =null;
	ResultSet rs = null;
	String query;

	@Override
	public boolean fundTransfer(FundBean fb) 
	{
		Date d = new Date();
		java.sql.Date date = new java.sql.Date(d.getTime());
		
		try 
		{
			Class.forName(DRIVERCLASS).newInstance();
			con = DriverManager.getConnection(DBURL, USER, PASSWORD);
			
			query = "insert into fund_transfer(ac_id,payee_ac_number,date_of_transfer,transfer_amount) value (?,?,?,?)";
			ps = con.prepareStatement(query);
			ps.setLong(1, fb.getAcId());
			ps.setLong(2, fb.getPayeeAcId());
			ps.setDate(3, date);
			ps.setDouble(4, fb.getTransferAmount());
			
			
			
			int count = ps.executeUpdate();
			
			if(count>0)
			{
				System.out.println("Data inserted....");
				return true;
			}
			else
			{
				System.out.println("Invalid data or incomplete data ");
				return false;
			}
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
			System.out.println(e);
		}
		return false;
	}

	@Override
	public void updateBalance(FundBean fb, double bal) 
	{
		try 
		{
			Class.forName(DRIVERCLASS).newInstance();
			con = DriverManager.getConnection(DBURL, USER, PASSWORD);			
			query="update account_master set balance =? where ac_id=?";
			ps = con.prepareStatement(query);
			
			double newBal = bal - fb.getTransferAmount();
			
			ps.setDouble(1, newBal);
			ps.setLong(2, fb.getAcId());
			
			int count = ps.executeUpdate();
			
			if(count>0)
			{
				System.out.println("Account bal is updated ");
			}
			else
			{
				System.out.println("Invalid data or incomplete data ");
			}
		}
		catch (Exception e) 
		{
			e.printStackTrace();
		}
		
	}
	
}
