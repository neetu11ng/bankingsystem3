package com.caps.banking.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Date;

import com.caps.banking.dto.RequestBean;
import com.caps.banking.utils.DBUtils;

public class RequestImpl implements RequestI, DBUtils
{

	Connection con =null;
	PreparedStatement ps =null;
	ResultSet rs = null;
	String query;
	
	@Override
	public boolean checkRequest(RequestBean rb) 
	{
		Date date = rb.getRequestDate();
		java.sql.Date d = new java.sql.Date(date.getTime());
		try 
		{
			Class.forName(DRIVERCLASS).newInstance();
			//DriverManager.registerDriver(driver);
			con = DriverManager.getConnection(DBURL, USER, PASSWORD);
			
			query="insert into service_tracker values (?,?,?,?,?)";
			ps = con.prepareStatement(query);
			ps.setLong(1, rb.getServiceId());
			ps.setString(2, rb.getServiceDesc());
			ps.setInt(3, rb.getAcId());
			ps.setDate(4, d);
			ps.setString(5, rb.getStatus());
			
			int count = ps.executeUpdate();
			
			if(count>0)
			{
				System.out.println("Requested....");
				return true;
				
			}
			else
			{
				System.out.println("Invalid data or incomplete data ");
				return false;
			}
			
			
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
			System.out.println(e);
		}
		return false;
	}

}
