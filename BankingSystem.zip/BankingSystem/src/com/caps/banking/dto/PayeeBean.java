package com.caps.banking.dto;

public class PayeeBean 
{
	private long ac_id;
	private int payee_ac_num;
	private String nick_name;
	
	public long getAc_id() {
		return ac_id;
	}
	public void setAc_id(long accountId) {
		this.ac_id = accountId;
	}
	public int getPayee_ac_num() {
		return payee_ac_num;
	}
	public void setPayee_ac_num(int payee_ac_num) {
		this.payee_ac_num = payee_ac_num;
	}
	public String getNick_name() {
		return nick_name;
	}
	public void setNick_name(String nick_name) {
		this.nick_name = nick_name;
	}
	@Override
	public String toString() {
		return "PayeeBean [ac_id=" + ac_id + ", payee_ac_num=" + payee_ac_num + ", nick_name=" + nick_name + "]";
	}
}
