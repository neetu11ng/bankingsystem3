package com.caps.banking.dto;

import java.util.Date;

public class TransactionBean 
{
	private int transaction_id;
	private String tran_desc;
	private Date date_of_tran;
	private String transaction_type;
	private double tran_amount;
	private long ac_id;
	
	public long getAc_id() {
		return ac_id;
	}
	public void setAc_id(long ac_id) {
		this.ac_id = ac_id;
	}
	public void setTran_amount(double tran_amount) {
		this.tran_amount = tran_amount;
	}
	public int getTransaction_id() {
		return transaction_id;
	}
	public void setTransaction_id(int transaction_id) {
		this.transaction_id = transaction_id;
	}
	public String getTran_desc() {
		return tran_desc;
	}
	public void setTran_desc(String tran_desc) {
		this.tran_desc = tran_desc;
	}
	public Date getDate_of_tran() {
		return date_of_tran;
	}
	public void setDate_of_tran(Date date_of_tran) {
		this.date_of_tran = date_of_tran;
	}
	public String getTransaction_type() {
		return transaction_type;
	}
	public void setTransaction_type(String transaction_type) {
		this.transaction_type = transaction_type;
	}
	public double getTran_amount() {
		return tran_amount;
	}
	public void setTran_amount(int tran_amount) {
		this.tran_amount = tran_amount;
	}
	
	

}
