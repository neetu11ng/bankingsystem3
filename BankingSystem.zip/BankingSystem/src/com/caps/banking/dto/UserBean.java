package com.caps.banking.dto;

public class UserBean 
{
	
	private String uname;
	private String email;
	private String address;
	private String pan;
	private int ac_no;
	private int contact;
	
	private long ac_id;
	private String user_id;
	private String login_password;
	private String secret_question;
	private String answer;
	private String transaction_password;
	private String lock_status;
	
	
	public int getContact() {
		return contact;
	}
	public void setContact(int contact) {
		this.contact = contact;
	}
	public long getAc_id() {
		return ac_id;
	}
	public void setAc_id(long ac_no2) {
		this.ac_id = ac_no2;
	}
	
	public String getUser_id() {
		return user_id;
	}
	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}
	public String getLogin_password() {
		return login_password;
	}
	public void setLogin_password(String i) {
		this.login_password = i;
	}
	public String getSecret_question() {
		return secret_question;
	}
	public void setSecret_question(String secret_question) {
		this.secret_question = secret_question;
	}
	public String getAnswer() {
		return answer;
	}
	public void setAnswer(String answer) {
		this.answer = answer;
	}
	public String getTransaction_password() {
		return transaction_password;
	}
	public void setTransaction_password(String i) {
		this.transaction_password = i;
	}
	public String getLock_status() {
		return lock_status;
	}
	public void setLock_status(String lock_status) {
		this.lock_status = lock_status;
	}
	
	//customer details
	public String getUname() {
		return uname;
	}
	public void setUname(String uname) {
		this.uname = uname;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getPan() {
		return pan;
	}
	public void setPan(String pan) {
		this.pan = pan;
	}
	public int getAc_no() {
		return ac_no;
	}
	public void setAc_no(int ac_no) {
		this.ac_no = ac_no;
	}
	@Override
	public String toString() {
		return "UserBean [ac_id=" + ac_id + ", user_id=" + user_id + ", login_password=" + login_password
				+ ", secret_question=" + secret_question + ", answer=" + answer + ", transaction_password="
				+ transaction_password + ", lock_status=" + lock_status + "]";
	}

}
