package com.caps.banking.dto;

public class FundBean 
{
	private long fundTransferId;
	private long acId;
	private long payeeAcId;
	private String dateOfTransfer;
	private double transferAmount;
	
	public long getFundTransferId() {
		return fundTransferId;
	}
	public void setFundTransferId(long fundTransferId) {
		this.fundTransferId = fundTransferId;
	}
	public long getAcId() {
		return acId;
	}
	public void setAcId(long ac) {
		this.acId = ac;
	}
	public long getPayeeAcId() {
		return payeeAcId;
	}
	public void setPayeeAcId(long payeeNo) {
		this.payeeAcId = payeeNo;
	}
	public String getDateOfTransfer() {
		return dateOfTransfer;
	}
	public void setDateOfTransfer(String dateOfTransfer) {
		this.dateOfTransfer = dateOfTransfer;
	}
	public double getTransferAmount() {
		return transferAmount;
	}
	public void setTransferAmount(double transferAmount) {
		this.transferAmount = transferAmount;
	}
	@Override
	public String toString() {
		return "FundBean [fundTransferId=" + fundTransferId + ", acId=" + acId + ", payeeAcId=" + payeeAcId
				+ ", dateOfTransfer=" + dateOfTransfer + ", transferAmount=" + transferAmount + "]";
	}
}
