package com.caps.banking.dto;

import java.util.Date;

public class NewAccountBean 
{
	private long acId;
	private String acType;
	private double bal;
	private Date openDate;
	
	public long getAcId() {
		return acId;
	}
	public void setAcId(long ac_no) {
		this.acId = ac_no;
	}
	public String getAcType() {
		return acType;
	}
	public void setAcType(String acType) {
		this.acType = acType;
	}
	public double getBal() {
		return bal;
	}
	public void setBal(double bal) {
		this.bal = bal;
	}
	public Date getOpenDate() {
		return openDate;
	}
	public void setOpenDate(Date openDate) {
		this.openDate = openDate;
	}
	@Override
	public String toString() {
		return "NewAccountBean [acId=" + acId + ", acType=" + acType + ", bal=" + bal + ", openDate=" + openDate + "]";
	}
	
	
}
