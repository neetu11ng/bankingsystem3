package com.caps.banking.service;

import java.sql.ResultSet;
import java.sql.SQLException;

import com.caps.banking.dao.BankingDAOImpl;
import com.caps.banking.dto.NewAccountBean;
import com.caps.banking.dto.UserBean;

public class BankExtraService 
{
	// fetching details of requested user
	public ResultSet fetch()
	{
		BankingDAOImpl dao = new BankingDAOImpl();
		ResultSet rs = dao.fetching();
		return rs;
	}
	
	// fetching details of verified user
	public ResultSet verifiedUser()
	{
		BankingDAOImpl dao = new BankingDAOImpl();
		ResultSet rs = dao.verifiedUser();
		return rs;
	}
	
	public ResultSet view(String id)
	{
		BankingDAOImpl dao = new BankingDAOImpl();
		ResultSet rs = dao.viewDetails(id);
		return rs;
	}
	
	//verify user service 
	public void verify(String id)
	{
		BankingDAOImpl dao = new BankingDAOImpl();
		dao.verifyUser(id);
	}
	
	//insert account id and user id in user table
	public void insUser(UserBean ub)
	{
		BankingDAOImpl dao = new BankingDAOImpl();
		dao.insUser(ub);
	}
	
	//creating new account service
	public boolean newAccount(NewAccountBean nb)
	{
		BankingDAOImpl dao = new BankingDAOImpl();
		boolean b = dao.createNewAccount(nb);
		return b;
	}
	
	public ResultSet accountDetails(long acid) throws SQLException
	{
		BankingDAOImpl dao = new BankingDAOImpl();
		ResultSet rs = dao.accountDetails(acid);
		return rs;
	}
}
