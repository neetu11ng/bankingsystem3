package com.caps.banking.service;

import java.sql.ResultSet;

import com.caps.banking.dao.PayeeImpl;
import com.caps.banking.dto.PayeeBean;

public class PayeeService 
{
	public boolean  addContact(PayeeBean pb)
	{
		PayeeImpl pi = new PayeeImpl();
		boolean add = pi.addPayee(pb);
		return add;
	}
	public boolean checkId(int acid)
	{
		PayeeImpl pi = new PayeeImpl();
		boolean check =pi.checkAccountId(acid);
		return check;
	}
	
	public ResultSet allDetails(long acid)
	{
		PayeeImpl pi = new PayeeImpl();
		ResultSet rs = pi.fetchPayeeDetails(acid);
		return rs;
	}
	public ResultSet allDetailByName(String name)
	{
		PayeeImpl pi = new PayeeImpl();
		ResultSet rs = pi.PayeeDetails(name);
		return rs;
	}
}
