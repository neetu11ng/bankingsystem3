package com.caps.banking.service;

import com.caps.banking.dao.TransImpl;
import com.caps.banking.dto.TransactionBean;

public class TransactionService 
{
	
	public boolean  view(TransactionBean tb)
	{
		TransImpl bl = new TransImpl();
		boolean vw = bl.viewTransaction(tb.getTransaction_id());
		return vw;
	}
	
	public void  createTrans(TransactionBean tb)
	{
		TransImpl t = new TransImpl();
		t.insertTransaction(tb);
	}
}
