package com.caps.banking.service;

import com.caps.banking.dao.FundImpl;
import com.caps.banking.dto.FundBean;

public class FundService 
{
	public boolean funding(FundBean fb)
	{
		FundImpl fi = new FundImpl();
		boolean f = fi.fundTransfer(fb);
		return f ;
	}
	
	public void updateBal(FundBean fb,double bal)
	{
		FundImpl fi = new FundImpl();
		fi.updateBalance(fb, bal);
	}
}
