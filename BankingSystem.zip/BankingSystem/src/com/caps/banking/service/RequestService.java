package com.caps.banking.service;

import com.caps.banking.dao.RequestImpl;
import com.caps.banking.dao.UserImpl;
import com.caps.banking.dto.RequestBean;
import com.caps.banking.dto.UserBean;

public class RequestService 
{
	//requested for check book
	public boolean chkbookReq(RequestBean rb) 
	{
		RequestImpl u = new RequestImpl();
		boolean b = u.checkRequest(rb);
		return b;
	}
}
