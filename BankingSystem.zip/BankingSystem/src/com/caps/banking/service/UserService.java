package com.caps.banking.service;

import java.sql.ResultSet;

import com.caps.banking.dao.UserImpl;
import com.caps.banking.dto.UserBean;

public class UserService 
{
	//registration or apply for new customer
	public boolean userRegister (UserBean ub)
	{
		UserImpl u = new UserImpl();
		boolean b = u.register(ub);
		return b;
	}
	//login
	public boolean userLogin (UserBean ub)
	{
		UserImpl u = new UserImpl();
		boolean b = u.login(ub);
		return b;
	}
	
	public boolean allDetails(UserBean ub)
	{
		UserImpl u = new UserImpl();
		boolean b =  u.details(ub);
		return b;
	}
	//fetching details of particular user
	public ResultSet fetchData(UserBean ub)
	{
		UserImpl u = new UserImpl();
		ResultSet rs = u.fetchData(ub);
		return rs;
	}

	// fetching details of particular user form customer table
	public ResultSet fetchDataCustomer(UserBean ub) 
	{
		UserImpl u = new UserImpl();
		ResultSet rs = u.fetchDataCustomer(ub);
		return rs;
	}
	
	//update user password
	public boolean updatePassword(UserBean ub)
	{
		UserImpl u = new UserImpl();
		boolean b =  u.updatePass(ub);
		return b;
	}
	//update user mobile
	public boolean updateMobile(UserBean ub) 
	{
		UserImpl u = new UserImpl();
		boolean b = u.updateMob(ub);
		return b;
	}
}
