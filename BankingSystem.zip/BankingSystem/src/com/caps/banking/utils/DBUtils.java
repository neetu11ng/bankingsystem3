package com.caps.banking.utils;

public interface DBUtils 
{
	String USER = "root";
	String PASSWORD ="root";
	String DBURL = "jdbc:mysql://localhost:3306/banking_db";
	String DRIVERCLASS = "com.mysql.cj.jdbc.Driver";
}
